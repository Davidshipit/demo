console.log("YouTube Clone Loaded");

document.querySelector('input[type="text"]').addEventListener('keypress', function (e) {
  if (e.key === 'Enter') {
    alert("Search not implemented in static version.");
  }
});
